setwd("C:\\Users\\FMT\\Desktop\\IT24102004\\Lab05")
getwd()
Delivery_Times <- read.table("Exercise - Lab 05.txt", header=TRUE)

fix(Delivery_Times)
names(Delivery_Times)<-c("X1")
attach(Delivery_Times)

head(Delivery_Times)

hist(Delivery_Times$Time,
     breaks=seq(20, 70, length.out=10), 
     right=FALSE,                       
     main="Histogram of Delivery Times",
     xlab="Delivery Time",
     ylab="Frequency"
     
     
     hist_data <- hist(Delivery_Times$Time,
                       breaks=seq(20, 70, length.out=10),
                       right=FALSE,
                       plot=FALSE)
     
     

     # Calculate cumulative frequency
     cum_freq <- cumsum(hist_data$counts)
     
     # Plot cumulative frequency polygon (Ogive)
     plot(hist_data$breaks[-1], cum_freq, type="o",
          main="Cumulative Frequency Polygon (Ogive)",
          xlab="Delivery Time",
          ylab="Cumulative Frequency")
     